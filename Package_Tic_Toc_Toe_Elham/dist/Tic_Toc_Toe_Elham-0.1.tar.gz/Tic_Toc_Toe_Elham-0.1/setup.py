
from setuptools import setup

setup(name='Tic_Toc_Toe_Elham',
      version='0.1',
      description='Tic_Toc_Toe_game',
      packages=['Tic_Toc_Toe_Elham'],
      zip_safe=False)

